﻿namespace CRUDAPI.Models
{
    public class TodoItem
    {
        public long Id { get; set; }
        public string? Task { get; set; }
        public bool isCompleted { get; set; }
    }
}
